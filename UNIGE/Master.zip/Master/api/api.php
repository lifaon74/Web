<?php 

function getJSONLastError() {
	static $errors = array(
		JSON_ERROR_NONE             => null,
		JSON_ERROR_DEPTH            => "The maximum stack depth has been exceeded",
		JSON_ERROR_STATE_MISMATCH   => "Invalid or malformed JSON",
		JSON_ERROR_CTRL_CHAR        => "Control character error, possibly incorrectly encoded",
		JSON_ERROR_SYNTAX           => "Syntax error",
		JSON_ERROR_UTF8             => "Malformed UTF-8 characters, possibly incorrectly encoded",
		JSON_ERROR_RECURSION		=> "One or more recursive references in the value to be encoded",
		JSON_ERROR_INF_OR_NAN		=> "One or more NAN or INF values in the value to be encoded",
		JSON_ERROR_UNSUPPORTED_TYPE	=> "A value of a type that cannot be encoded was given"
	);
	$error = json_last_error();
	return array_key_exists($error, $errors) ? $errors[$error] : "Unknown error ({$error})";
}





if(!isset($fnc)) { require_once('../scripts/php/fnc.php'); }
require_once($fnc->absolutePath('scripts/php/APIFunctions.php'));

//echo "result :\n";

//$APIFunctions->initialize();
//$APIFunctions->clearAll();
//exit();

//$script = "post_publication";
//$script = "get_publication";
//$script = "get_publication_2";
//$script = "get_publications";
//$script = "remove_publication";
//$script = "remove_publication_2";
//$script = "request_for_a_new_relationship";
//$script = "get_notifications";
//$script = "answer_notification";

//$script = "get_relationships";
//$script = "remove_relationship";

//$script = "request_for_a_new_owner_2";
//$script = "answer_notification_2";
//$script = "authenticate";

//print_r($APIFunctions->listOwnedObjects("NFEHXsRY7EOKcjMLayzhNOVifHDKXNo9e8FpfeWgE2k="));
/*print_r($APIFunctions->authenticateUser('test', 'test1'));
exit();*/

//$_REQUEST['query'] = file_get_contents($fnc->absolutePath('scripts/queries/' . $script . '.json'));

$reply = $APIFunctions->executeQueryFromREQUEST();
//print_r($reply);

$reply = json_encode($reply);
echo $reply;
				
/*switch($query->action) {

				// relations
			case "ask_for_relationship":
				if(authenticate($query)) {
					$notificationID = $APIFunctions->createNotification($query->action, $query->parameters->with_object, (object) [
						"relationship"	=> $query->parameters->relationship,
						"with_object"	=> $query->id
					]);
					$reply->response->notification_id = $notificationID;
				}
			break;
			case "get_relationships":
				if(authenticate($query)) {
					$relationships = $APIFunctions->getRelationships($query->parameters->of_object);
					$reply->response->relationships = $relationships;
				}
			break;
			case "remove_relationship":
				if(authenticate($query)) {
					$APIFunctions->removeRelationshipBetweenObjects($query->id, $query->parameters->relationship, $query->parameters->with_object);
					$notificationID = $APIFunctions->createNotification("remove_relationship", $query->parameters->with_object, (object) [
						"relationship"	=> $query->parameters->relationship,
						"with_object"	=> $query->id
					]);
				}
			break;
		}*/
		
?>