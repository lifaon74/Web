var core = {};

fnc.require(['Class', 'DOM', 'AJAXRequest'], function() {
	
	DOM.disableDynamicCSS();
	
	core.answerDomElement = DOM.find('#answer')[0];
	core.users		= [];
	core.objects	= [];
	
	core.generateRandomKey = function() {
		var key = "";
		for(var i = 0; i < 32; i++) {
			key += String.fromCharCode(Math.rand(0, 255));
		}
		return btoa(key);
	}
	
	core.sendQuery = function(query, callback) {
		var req = new AJAXRequest({
			'url'			: 'api/api.php',
			'type'			: 'post',
			'responseType'	: 'json',
			'data'			: { 'query' : JSON.stringify(query) },
			'oncomplete'	: function(response) {
				var html = "";
				switch(response.code) {
					case 0:
						html = JSON.stringify(response.response);
						if(typeof callback == 'function') {
							callback(response.response);
						}
					break;
					default:
						html = "[ERROR " + response.code + "] : " + response.message;
					break;
				}
				
				core.answerDomElement.setInnerHTML(html);
			},
			'onfail'		: function() {
				console.error("failed to load content !");
			}
		});
	}
	
	core.register_user = function() {
		core.sendQuery({
			"action"		: "register_user",
			"parameters"	: {
				"email"		: DOM.find('#register_user .email')[0].val(),
				"password"	: DOM.find('#register_user .password')[0].val()
			}
		}, function(response) {
			core.users.push(response);
		});
	};
	
	DOM.find('#register_user input[type=button]')[0].bind('click', core.register_user);
	
	core.register_object = function() {
		core.sendQuery({
			"action"		: "register_object",
			"parameters"	: {
				"id"		: core.generateRandomKey(),
				"key"		: core.generateRandomKey(),
				"name"		: DOM.find('#register_object .name')[0].val(),
				"type"		: DOM.find('#register_object .type')[0].val()
			}
		}, function(response) {
			core.objects.push(response);
		});
	};
	
	DOM.find('#register_object input[type=button]')[0].bind('click', core.register_object);
	
	
	/*var core.register_object = function() {
		
		sendQuery({
			"action"		: "register_objectr",
			"parameters"	: {
				"email"		: DOM.find('#register_user .email')[0].val(),
				"password"	: DOM.find('#register_user .password')[0].val()
			}
		}, function(response) {
			users.push(response);
		});
	};
	
	DOM.find('#register_object input[type=button]')[0].bind('click', register_object);*/
	
	//DOM.find();
	

});