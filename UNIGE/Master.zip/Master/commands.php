<!DOCTYPE html>
<html>
	<head>
		<title>ThingBook - Commands</title>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="Content-Language" content="fr"/>


		<link rel="stylesheet" type="text/css" href="scripts/css/style.acss"/>
		<link rel="stylesheet" type="text/css" href="scripts/css/commands.acss"/>
		
		<script type="text/javascript" src="../../Libraries/js/fnc.js"></script>
		<script type="text/javascript" src="scripts/js/commands.js"></script>
	</head>
	
		
	<body>
		<div id="answer" class="command">
			
		</div>
		
		<div id="register_user" class="command">
			<span>email : </span><input type="text" class="email"/>
			<span>mdp : </span><input type="text" class="password"/>
			<input type="button" value="Enregistrer l'utilisateur"/>
		</div>
		
		<div id="register_object" class="command">
			<span>nom : </span><input type="text" class="name"/>
			<span>type : </span><input type="text" class="type"/>
			<input type="button" value="Enregistrer l'objet"/>
		</div>
	</body>
</html>